# Class Reference
This page contains the syntax & parameter requirements for each function/method of the package.
## __XTS_Connect__
::: xts_api_client.xts_connect_async
## __interactive_socket_client__
::: xts_api_client.interactive_socket_client
## __interactive_socket__
::: xts_api_client.interactive_socket
## __market_data_socket_client__
::: xts_api_client.market_data_socket_client
## __market_data_socket__
::: xts_api_client.market_data_socket
