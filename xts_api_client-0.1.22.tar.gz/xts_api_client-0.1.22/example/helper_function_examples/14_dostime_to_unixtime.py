from xts_api_client.helper.helper import dostime_secomds_to_unixtime

print(dostime_secomds_to_unixtime(1420378549, "UTC"))